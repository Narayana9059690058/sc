import Calculator from "./Components/Calculator";
function App() {
  return (
    <div>
      <Calculator />
    </div>
  );
}

export default App;

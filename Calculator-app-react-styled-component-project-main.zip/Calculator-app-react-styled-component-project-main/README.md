# Calcuulator application using React & Styled Component
# video tutorial : Technfoyt Youtube Channel
- https://www.youtube.com/techinfoyt
- like and subscribe
- also please give credit in your app like channel name or link
- more mern and nextjs tutorials are in channel plese check out

# How to use this project
- if you want compare code just explore code
- if you want to directly use just go to project path and type npm install
- after that run app with : # npm start
- your app will run on port 3000 http://localhost:3000
